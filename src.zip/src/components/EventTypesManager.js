// EventTypesManager.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

// API base URL
const API_BASE_URL = 'http://localhost:5001/api';

// Default event types that cannot be deleted
const DEFAULT_EVENT_TYPES = [
];

const EventTypesManager = ({ onEventTypesChange }) => {
  const [eventTypes, setEventTypes] = useState([]);
  
  const [newTypeName, setNewTypeName] = useState('');
  const [newTypeIcon, setNewTypeIcon] = useState('📅');
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Load courses
  useEffect(() => {
    const loadCourses = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/courses`);
        setCourses(response.data);
      } catch (error) {
        console.error("Error fetching courses:", error);
        // Fall back to empty array if API fails
        setCourses([]);
      }
    };
    
    loadCourses();
  }, []);
  
  // Load event types from API instead of localStorage
  useEffect(() => {
    const loadEventTypes = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/event-types`);
        setEventTypes(response.data);
        setLoading(false);
        
        // Notify parent component if callback is provided
        if (onEventTypesChange) {
          onEventTypesChange(response.data);
        }
      } catch (error) {
        console.error("Error fetching event types:", error);
        setEventTypes(DEFAULT_EVENT_TYPES);
        setLoading(false);
      }
    };
    
    loadEventTypes();
  }, [onEventTypesChange]);
  
  const handleAddEventType = async () => {
    if (newTypeName.trim()) {
      const newType = {
        id: `type-${Date.now()}`, // We'll keep this ID format for consistency
        name: newTypeName.trim(),
        icon: newTypeIcon,
        color: '#808080', // Default color to match the UI preview
        relatedCourses: selectedCourses.length > 0 ? selectedCourses : null
      };
      
      try {
        // Save to API instead of localStorage
        await axios.post(`${API_BASE_URL}/event-types`, newType);
        
        // Fetch the updated list from the server to ensure consistency
        const response = await axios.get(`${API_BASE_URL}/event-types`);
        setEventTypes(response.data);
        
        // Notify parent component if callback is provided
        if (onEventTypesChange) {
          onEventTypesChange(response.data);
        }
        
        resetForm();
      } catch (error) {
        console.error("Error adding event type:", error);
      }
    }
  };
  
  const handleDeleteEventType = async (typeId) => {
    // Prevent deletion of default event types
    if (DEFAULT_EVENT_TYPES.some(type => type.id === typeId)) {
      return;
    }
    
    try {
      // Delete from API instead of localStorage
      await axios.delete(`${API_BASE_URL}/event-types/${typeId}`);
      
      // Update the local state to reflect the deletion
      const updatedEventTypes = eventTypes.filter(type => type.id !== typeId);
      setEventTypes(updatedEventTypes);
      
      // Notify parent component if callback is provided
      if (onEventTypesChange) {
        onEventTypesChange(updatedEventTypes);
      }
    } catch (error) {
      console.error("Error deleting event type:", error);
    }
  };
  
  const resetForm = () => {
    setNewTypeName('');
    setNewTypeIcon('📅');
    setSelectedCourses([]);
  };
  
  const handleCourseSelection = (e) => {
    const courseId = e.target.value;
    
    if (courseId === '') return;
    
    if (selectedCourses.includes(courseId)) {
      setSelectedCourses(selectedCourses.filter(id => id !== courseId));
    } else {
      setSelectedCourses([...selectedCourses, courseId]);
    }
    
    // Reset the select box
    e.target.value = '';
  };
  
  const removeSelectedCourse = (courseId) => {
    setSelectedCourses(selectedCourses.filter(id => id !== courseId));
  };
  
  // Common icons for event types
  const commonIcons = ['📅', '📚', '📝', '⏰', '👥', '🎓', '🏆', '💼', '🔍', '🎯'];
  
  const isDefaultType = (typeId) => {
    return DEFAULT_EVENT_TYPES.some(type => type.id === typeId);
  };
  
  if (loading) {
    return <div>טוען...</div>;
  }
  
  return (
    <div className="event-types-manager">
      <h3>סוגי אירועים</h3>
      
      <div className="items-list">
        {eventTypes.length > 0 ? (
          <ul>
            {eventTypes.map(type => (
              <li key={type.id} className="item-row">
                <div className="event-type-info">
                  <span className="event-type-icon">{type.icon}</span>
                  <span className="event-type-name">{type.name}</span>
                  
                  {/* Display related courses if any */}
                  {type.relatedCourses && type.relatedCourses.length > 0 && (
                    <div className="related-courses">
                      <small>
                        קורסים: {type.relatedCourses.map(courseId => {
                          const course = courses.find(c => c.id === courseId);
                          return course ? course.name : '';
                        }).filter(Boolean).join(', ')}
                      </small>
                    </div>
                  )}
                </div>
                
                {/* Don't allow deleting default types */}
                {!isDefaultType(type.id) && (
                  <button 
                    className="btn btn-danger btn-small" 
                    onClick={() => handleDeleteEventType(type.id)}
                  >
                    הסר
                  </button>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <div className="no-items">
            אין סוגי אירועים. הוסף סוג אירוע חדש למעלה.
          </div>
        )}
      </div>
      
      <div className="add-event-type-form">
        <h4>הוסף סוג אירוע חדש</h4>
        
        <div className="form-group">
          <label>שם סוג האירוע</label>
          <input 
            type="text"
            value={newTypeName}
            onChange={(e) => setNewTypeName(e.target.value)}
            className="form-input"
            placeholder="שם סוג האירוע"
          />
        </div>
        
        <div className="form-group">
          <label>אייקון</label>
          <div className="icons-selector">
            {commonIcons.map((icon, index) => (
              <button
                key={index}
                type="button"
                className={`icon-button ${newTypeIcon === icon ? 'selected' : ''}`}
                onClick={() => setNewTypeIcon(icon)}
              >
                {icon}
              </button>
            ))}
            <input 
              type="text"
              value={newTypeIcon}
              onChange={(e) => setNewTypeIcon(e.target.value)}
              className="form-input icon-input"
              placeholder="אייקון (אימוג'י)"
              maxLength={2}
            />
          </div>
        </div>
        
        <div className="form-group">
          <label>קורסים קשורים (אופציונלי)</label>
          <select
            className="form-input"
            onChange={handleCourseSelection}
            defaultValue=""
          >
            <option value="">בחר קורס...</option>
            {courses
              .filter(course => !selectedCourses.includes(course.id))
              .map(course => (
                <option key={course.id} value={course.id}>
                  {course.name}
                </option>
              ))
            }
          </select>
          
          {/* Display selected courses */}
          {selectedCourses.length > 0 && (
            <div className="selected-courses">
              {selectedCourses.map(courseId => {
                const course = courses.find(c => c.id === courseId);
                return course ? (
                  <div key={courseId} className="selected-course-tag">
                    <span>{course.name}</span>
                    <button 
                      type="button"
                      className="remove-course-btn"
                      onClick={() => removeSelectedCourse(courseId)}
                    >
                      ×
                    </button>
                  </div>
                ) : null;
              })}
            </div>
          )}
        </div>
        
        <div className="preview-event-type" style={{ 
          padding: '12px',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginTop: '16px',
          marginBottom: '16px',
          fontWeight: 'bold',
          backgroundColor: '#808080'
        }}>
          <span style={{ fontSize: '1.5em' }}>{newTypeIcon}</span>
          <span>
            {newTypeName || 'תצוגה מקדימה של סוג האירוע'}
          </span>
        </div>
        
        <button className="btn btn-primary" onClick={handleAddEventType}>
          הוסף סוג אירוע
        </button>
      </div>
    </div>
  );
};

export default EventTypesManager;
