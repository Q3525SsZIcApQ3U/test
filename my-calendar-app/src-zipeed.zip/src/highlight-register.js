// highlight-register.js
import hljs from 'highlight.js';
import 'highlight.js/styles/atom-one-dark.css';

// Register highlight.js globally
window.hljs = hljs;

export default hljs;