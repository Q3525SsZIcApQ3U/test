import React, { useState, useEffect } from "react";
import Editor from "react-text-editor-kit";

const TextEditor = () => {
  const [content, setContent] = useState("");
  const [timeoutId, setTimeoutId] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5001/api/load-content")
      .then((res) => res.json())
      .then((data) => setContent(data.content))
      .catch((err) => console.error("Failed to load content:", err));
  }, []);

  const handleChange = (newContent) => {
    setContent(newContent);

    // Clear existing timeout to debounce saves
    if (timeoutId) clearTimeout(timeoutId);

    const newTimeoutId = setTimeout(() => {
      fetch("http://localhost:5001/api/save-content", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ content: newContent }),
      }).catch((err) => console.error("Failed to save content:", err));
    }, 1000); // Delay save by 1 second

    setTimeoutId(newTimeoutId);
  };

  return (
    <div>
      <Editor value={content} onChange={handleChange} />
    </div>
  );
};

export default TextEditor;
