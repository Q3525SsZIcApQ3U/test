import React, { useState } from "react";
import { Drawer, CssBaseline, Box, IconButton, Button } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import CalendarComponent from "./CalendarComponent";
import TextEditor from "./TextEditor";

const drawerWidth = 300; // Adjust width as needed

const App = () => {
  const [open, setOpen] = useState(false);

  const toggleDrawer = () => {
    setOpen(!open);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />

      {/* Toggle Button (Can be anywhere) */}
      <IconButton
        onClick={toggleDrawer}
        sx={{ position: "absolute", top: 10, left: 10, zIndex: 1000 }}
      >
        <MenuIcon />
      </IconButton>

      {/* Sidebar Drawer */}
      <Drawer
        variant="persistent"
        anchor="left"
        open={open}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
            padding: 2,
          },
        }}
      >
        {/* Text Editor Inside Drawer */}
        <Button onClick={toggleDrawer} variant="contained" color="secondary">
          Close
        </Button>
        <TextEditor />
      </Drawer>

      {/* Main Content (Calendar) - Shifts Right When Drawer Opens */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          padding: 2,
          transition: "margin 0.3s ease-out",
          marginLeft: open ? `${drawerWidth}px` : 0,
        }}
      >
        <CalendarComponent />
      </Box>
    </Box>
  );
};

export default App;
